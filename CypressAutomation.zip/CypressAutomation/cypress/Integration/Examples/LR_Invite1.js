describe('Invite Form', () => {
    it('fills out the form and proceeds to identity verification', () => {
        cy.visit('https://dev.rentpillar.com/invite/d4nym-u854')

        // Wait for the first name input field to be visible and then interact with it
        cy.get('[name="first_name"]').should('be.visible').invoke('removeAttr', 'disabled').clear().type('John')

        // Similarly, wait for other elements and interact with them
        cy.get('[name="last_name"]').should('be.visible').invoke('removeAttr', 'disabled').clear().type('Doe')

        cy.get('[name="email"]').should('be.visible').invoke('removeAttr', 'disabled').clear().type('john.doe@example.com')

        cy.get('[name="socialSecurityNumber"]').should('be.visible').invoke('removeAttr', 'disabled').clear().type('123123123')

        cy.get('[name="DOB"]').should('be.visible').invoke('removeAttr', 'disabled').clear().type('1990-01-01')

        // Enable the terms and conditions checkbox and click on it (forcing it)
        cy.get('.MuiCheckbox-root input[type="checkbox"]').invoke('removeAttr', 'disabled').check({ force: true })

        // Click the button to proceed to open the window/modal
        cy.contains('Accept Terms & Conditions to proceed').click()

        // Wait for the modal/window to open
        cy.get('.MuiDialogContent-root').should('be.visible')

        // Pause the test execution until the "Agree" button is clicked manually
        cy.pause()

        // After manual interaction, assert that the "Proceed to Identity Verification" button is visible
        cy.get('[id=":r5:"]').should('be.visible')

        // Click the "Proceed to Identity Verification" button
        cy.contains('Proceed To Identity Verification').click()

        // Assert that the user has proceeded to identity verification
        cy.url().should('include', '/identity-verification')
    })
})
