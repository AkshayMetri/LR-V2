describe('Yahoo Mail Login Test', () => {
  it('Logs into Yahoo Mail successfully', () => {
      // Visit Yahoo Mail's login page
      cy.visit('https://login.yahoo.com/');
      
      // Enter email and submit
      cy.get('#login-username').type('akshaymetri@rocketmail.com').type('{enter}');
      
      // Wait for the page to load after submitting the email
      cy.url().should('include', 'challenge/push');
      
      // Assert that we are redirected to the push notification challenge page
      cy.contains('Yes, send me a notification').click();

      // After clicking the notification button, assert that we are redirected to the expected page
      cy.url().should('include', 'mail.yahoo.com');
  });
});
